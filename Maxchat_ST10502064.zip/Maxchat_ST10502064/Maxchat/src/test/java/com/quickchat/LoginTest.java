package com.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class LoginTest {

  

    private Login validLogin; 
    private Login invalidLogin; 

    @BeforeEach
    public void setUp() {
       
        validLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");

       
        invalidLogin = new Login("Test", "User", "kyle!!!!!!!", "password", "08966553");
    }

    @Test
    public void testCheckUserName_CorrectlyFormatted() {
        
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.checkUserName(),
                "Username 'kyl_1' should be valid (contains underscore and <= 5 chars).");
    }


    @Test
    public void testCheckUserName_IncorrectlyFormatted() {
    
        Login login = new Login("Test", "User", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.checkUserName(),
                "Username 'kyle!!!!!!!' should be invalid (no underscore, too long).");
    }

   
    @Test
    public void testCheckPasswordComplexity_ValidPassword() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.checkPasswordComplexity(),
                "Password 'Ch&&sec@ke99!' should meet all complexity rules.");
    }

  
    @Test
    public void testCheckPasswordComplexity_InvalidPassword() {
        Login login = new Login("Test", "User", "kyl_1", "password", "+27838968976");
        assertFalse(login.checkPasswordComplexity(),
                "Password 'password' should fail complexity check.");
    }


    @Test
    public void testCheckCellPhoneNumber_Valid() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.checkCellPhoneNumber(),
                "Cell '+27838968976' should be valid (starts with +27, correct length).");
    }

  
    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        Login login = new Login("Test", "User", "kyl_1", "Ch&&sec@ke99!", "08966553");
        assertFalse(login.checkCellPhoneNumber(),
                "Cell '08966553' should be invalid (no international code).");
    }

    @Test
    public void testLoginUser_Successful() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"),
                "Login should succeed with correct credentials.");
    }

    @Test
    public void testLoginUser_Failed() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrongpassword"),
                "Login should fail with incorrect password.");
    }


    @Test
    public void testReturnLoginStatus_Success() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        String expected = "Welcome Kyle Smith it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus(true));
    }

 
    @Test
    public void testReturnLoginStatus_Failure() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus(false));
    }
}
