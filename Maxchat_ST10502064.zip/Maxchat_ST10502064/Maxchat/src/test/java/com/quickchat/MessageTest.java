package com.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class MessageTest {


    private Message validMessage;
    private Message invalidRecipientMessage;
    private Message longMessage;

    @BeforeEach
    public void setUp() {
    
        Message.resetTotalMessages();

     
        validMessage = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");

       
        invalidRecipientMessage = new Message("08575975889", "Hi Keegan, did you receive the payment?");

     
        longMessage = new Message("+27718693002",
                "A".repeat(260));
    }

   
    @Test
    public void testCheckMessageLength_ValidMessage() {
        assertEquals("Message ready to send.", validMessage.checkMessageLength(),
                "Message within 250 chars should return 'Message ready to send.'");
    }

   
    @Test
    public void testCheckMessageLength_MessageTooLong() {
    
        String expected = "Message exceeds 250 characters by 10; please reduce the size.";
        assertEquals(expected, longMessage.checkMessageLength(),
                "Message of 260 chars should report exceeding by 10.");
    }

 
    @Test
    public void testCheckRecipientCell_Valid() {
        assertEquals("Cell phone number successfully captured.",
                validMessage.checkRecipientCell(),
                "Recipient '+27718693002' should be valid.");
    }

    
    @Test
    public void testCheckRecipientCell_Invalid() {
        String expected = "Cell phone number is incorrectly formatted or does not contain "
                + "an international code. Please correct the number and try again.";
        assertEquals(expected, invalidRecipientMessage.checkRecipientCell(),
                "Recipient '08575975889' should be invalid (no international code).");
    }

   
    @Test
    public void testCreateMessageHash_CorrectFormat() {
        String hash = validMessage.getMessageHash();
        assertNotNull(hash, "Message hash should not be null.");
      
        assertTrue(hash.matches("[0-9]{2}:[0-9]+:[A-Z]+"),
                "Hash '" + hash + "' should match pattern XX:N:FIRSTLAST");
      
        assertTrue(hash.endsWith(":HITONIGHT") || hash.contains(":1:HITONIGHT"),
                "Hash should end with HITONIGHT. Actual: " + hash);
    }

    @Test
    public void testCheckMessageID_Valid() {
        assertTrue(validMessage.checkMessageID(),
                "Auto-generated message ID should be 10 chars or fewer.");
    }

  
    @Test
    public void testSentMessage_Send() {
        assertEquals("Message successfully sent.", validMessage.sentMessage(1),
                "Choosing Send should return 'Message successfully sent.'");
    }

 
    @Test
    public void testSentMessage_Disregard() {
        assertEquals("Press 0 to delete the message.", invalidRecipientMessage.sentMessage(2),
                "Choosing Disregard should return 'Press 0 to delete the message.'");
    }

    @Test
    public void testSentMessage_Store() {
        Message storeMsg = new Message("+27718693002", "Test store message.");
        assertEquals("Message successfully stored.", storeMsg.sentMessage(3),
                "Choosing Store should return 'Message successfully stored.'");
    }

    
    @Test
    public void testReturnTotalMessages() {
        Message.resetTotalMessages();
        Message m1 = new Message("+27718693002", "Message one.");
        Message m2 = new Message("+27718693002", "Message two.");
        assertEquals(2, Message.returnTotalMessages(),
                "After creating 2 messages, total should be 2.");
    }
}
