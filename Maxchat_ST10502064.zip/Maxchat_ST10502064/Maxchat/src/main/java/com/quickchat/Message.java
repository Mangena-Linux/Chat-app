package com.quickchat;

import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;


public class Message {

    private String messageID;      
    private int    numMessages;     
    private String recipient;       
    private String messageText;    
    private String messageHash;     
    private String status;       

  
    private static int totalMessagesSent = 0;

    public Message(String recipient, String messageText) {
        this.messageID   = generateMessageID();
        this.numMessages = ++totalMessagesSent;
        this.recipient   = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        this.status      = "";
    }

    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

  
    public String createMessageHash() {
       
        String idPrefix = messageID.substring(0, 2);

      
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord  = words[words.length - 1];

       
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String hash = idPrefix + ":" + numMessages + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

   
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

   
    public String checkRecipientCell() {
        if (recipient == null) {
            return "Cell phone number is incorrectly formatted or does not contain "
                    + "an international code. Please correct the number and try again.";
        }
       
        String regex = "^\\+27[0-9]{9}$";
        if (recipient.matches(regex)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain "
                    + "an international code. Please correct the number and try again.";
        }
    }

  
    public String checkMessageLength() {
        if (messageText == null) {
            return "Message ready to send.";
        }
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess
                    + "; please reduce the size.";
        }
    }

 
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                status = "Sent";
                return "Message successfully sent.";
            case 2:
                status = "Disregarded";
                // When disregarded, decrement total so the counter stays accurate
                totalMessagesSent--;
                numMessages--;
                return "Press 0 to delete the message.";
            case 3:
                status = "Stored";
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    
    public String printMessages() {
        return "Message ID: "   + messageID   + "\n"
             + "Message Hash: " + messageHash + "\n"
             + "Recipient: "    + recipient   + "\n"
             + "Message: "      + messageText;
    }

   
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

   
    public static void resetTotalMessages() {
        totalMessagesSent = 0;
    }

   
    public void storeMessage() {
        JSONObject json = new JSONObject();
        json.put("messageID",   messageID);
        json.put("messageHash", messageHash);
        json.put("recipient",   recipient);
        json.put("message",     messageText);
        json.put("status",      status);
        json.put("numMessage",  numMessages);

      
        try (FileWriter fw = new FileWriter("messages.json", true)) {
            fw.write(json.toString() + System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Error saving message to file: " + e.getMessage());
        }
    }

   
    public String getMessageID()    { return messageID; }
    public int    getNumMessages()  { return numMessages; }
    public String getRecipient()    { return recipient; }
    public String getMessageText()  { return messageText; }
    public String getMessageHash()  { return messageHash; }
    public String getStatus()       { return status; }
}
