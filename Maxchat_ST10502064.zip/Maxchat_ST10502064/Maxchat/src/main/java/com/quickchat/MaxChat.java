package com.quickchat;

import java.util.Scanner;


public class MaxChat {

   
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("         Welcome to MaxChat           ");
        System.out.println("========================================\n");


        Login user = registerUser();
        if (user == null) {
            System.out.println("Registration failed. Exiting.");
            return;
        }

      
        boolean loggedIn = loginUser(user);
        if (!loggedIn) {
            System.out.println("Too many failed attempts. Exiting.");
            return;
        }

      
        runMessagingMenu(user);

        scanner.close();
    }

    private static Login registerUser() {
        System.out.println("--- Registration ---\n");

        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine().trim();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine().trim();

        // Username validation loop
        String username = "";
        while (true) {
            System.out.print("Enter username (must contain '_' and be max 5 characters): ");
            username = scanner.nextLine().trim();

            Login temp = new Login(firstName, lastName, username, "Placeholder1!", "+270000000000");
            if (temp.checkUserName()) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your "
                        + "username contains an underscore and is no more than five characters in length.");
            }
        }

     
        String password = "";
        while (true) {
            System.out.print("Enter password (min 8 chars, 1 uppercase, 1 number, 1 special char): ");
            password = scanner.nextLine().trim();

            Login temp = new Login(firstName, lastName, username, password, "+270000000000");
            if (temp.checkPasswordComplexity()) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the "
                        + "password contains at least eight characters, a capital letter, a number, "
                        + "and a special character.");
            }
        }

       
        String cell = "";
        while (true) {
            System.out.print("Enter South African cell number (e.g. +27838968976): ");
            cell = scanner.nextLine().trim();

            Login temp = new Login(firstName, lastName, username, password, cell);
            if (temp.checkCellPhoneNumber()) {
                System.out.println("Cell phone number successfully added.\n");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain "
                        + "international code.");
            }
        }

        return new Login(firstName, lastName, username, password, cell);
    }

    private static boolean loginUser(Login user) {
        System.out.println("--- Login ---\n");

        int attempts = 0;
        int maxAttempts = 3;

        while (attempts < maxAttempts) {
            System.out.print("Username: ");
            String enteredUser = scanner.nextLine().trim();

            System.out.print("Password: ");
            String enteredPass = scanner.nextLine().trim();

            boolean success = user.loginUser(enteredUser, enteredPass);
            System.out.println(user.returnLoginStatus(success));

            if (success) {
                System.out.println();
                return true;
            }

            attempts++;
            if (attempts < maxAttempts) {
                System.out.println("Attempts remaining: " + (maxAttempts - attempts) + "\n");
            }
        }
        return false;
    }

    private static void runMessagingMenu(Login user) {
        System.out.println("Welcome to QuickChat.\n");

        
        int numMessagesAllowed = 0;
        while (numMessagesAllowed <= 0) {
            System.out.print("How many messages would you like to send? ");
            try {
                numMessagesAllowed = Integer.parseInt(scanner.nextLine().trim());
                if (numMessagesAllowed <= 0) {
                    System.out.println("Please enter a number greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }

        int messagesSentThisSession = 0;
        boolean running = true;

       
        while (running) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                   
                    if (messagesSentThisSession >= numMessagesAllowed) {
                        System.out.println("You have reached your message limit for this session.");
                    } else {
                        messagesSentThisSession = sendMessageFlow(messagesSentThisSession, numMessagesAllowed);
                    }
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    running = false;
                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }

    private static int sendMessageFlow(int messagesSentSoFar, int maxMessages) {
       
        while (messagesSentSoFar < maxMessages) {
            System.out.println("\n--- New Message (" + (messagesSentSoFar + 1)
                    + " of " + maxMessages + ") ---");

          
            String recipient = "";
            while (true) {
                System.out.print("Enter recipient cell number (e.g. +27838968976): ");
                recipient = scanner.nextLine().trim();

                Message tempMsg = new Message(recipient, "placeholder");
                String cellResult = tempMsg.checkRecipientCell();
                System.out.println(cellResult);

                if (cellResult.equals("Cell phone number successfully captured.")) {
                    break;
                }
            }

           
            String messageText = "";
            while (true) {
                System.out.print("Enter your message (max 250 characters): ");
                messageText = scanner.nextLine().trim();

                if (messageText.length() > 250) {
                    int excess = messageText.length() - 250;
                    System.out.println("Please enter a message of less than 250 characters.");
                    System.out.println("(Message exceeds 250 characters by " + excess
                            + "; please reduce the size.)");
                } else {
                    break;
                }
            }

           
            Message msg = new Message(recipient, messageText);

            System.out.println("\nMessage ID generated: " + msg.getMessageID());
            System.out.println("Message Hash: " + msg.getMessageHash());


            System.out.println("\nWhat would you like to do?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choose: ");

            int action = getIntInput();
            String actionResult = msg.sentMessage(action);
            System.out.println(actionResult);

            if (action == 1 || action == 3) {
              
                System.out.println("\n" + msg.printMessages());
                messagesSentSoFar++;

              
                if (action == 3) {
                    msg.storeMessage();
                }
            } else if (action == 2) {
              
                System.out.println("Message discarded. You can send a new one.");
            }

            
            if (messagesSentSoFar >= maxMessages) {
                System.out.println("\nAll " + maxMessages + " message(s) processed.");
                System.out.println("Total messages sent: " + Message.returnTotalMessages());
                break;
            }
        }

        return messagesSentSoFar;
    }

  
    private static int getIntInput() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
