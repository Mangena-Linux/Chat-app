package com.maxchat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Message class for MaxChat — covers Parts 2 and 3 of the PROG5121 POE. */

public class Message {

    // -----------------------
    // Static parallel arrays 
    // -----------------------
    
    private static final List<String> sentMessages        = new ArrayList<>();
    private static final List<String> sentRecipients      = new ArrayList<>();
    private static final List<String> disregardedMessages = new ArrayList<>();
    private static final List<String> storedMessages      = new ArrayList<>();
    private static final List<String> storedRecipients    = new ArrayList<>();
    private static final List<String> messageHashes       = new ArrayList<>();
    private static final List<String> messageIDs          = new ArrayList<>();
   
    /** Tracks whether each messageID slot belongs to "sent" or "stored". */
   
    private static final List<String> entryTypes          = new ArrayList<>();

    private static int totalMessagesSent = 0;

    
    private static final String JSON_FILE = "messages.json";

    private final String messageID;
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private final int    messageNumber;   // position in session (1-based)

    // -----------------------------------------------------------------------
    // Constructor used by the running application
    // -----------------------------------------------------------------------
    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageNumber = messageNumber;
        this.messageID     = generateMessageID();
        this.messageHash   = createMessageHash();
    }


    public Message(String recipient, String messageText, int messageNumber, String fixedID) {
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageNumber = messageNumber;
        this.messageID     = fixedID;
        this.messageHash   = createMessageHash();
    }

    // -----------------------------------------------------------------------
    // ID generation
    // -----------------------------------------------------------------------

  
    private String generateMessageID() {
        Random rng = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rng.nextInt(10));
        }
        return sb.toString();
    }

   
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // -----------------------------------------------------------------------
    // Recipient validation
    // -----------------------------------------------------------------------

   
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+[0-9]{1,3}[0-9]{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain "
                + "international code. Please correct the number and try again.";
    }

    // -----------------------------------------------------------------------
    // Message hash
    // -----------------------------------------------------------------------

   
    public String createMessageHash() {
        String idPart   = messageID.substring(0, Math.min(2, messageID.length()));
        String[] words  = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord  = words[words.length - 1];
        // Remove punctuation from last word for a clean hash
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");
        return (idPart + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // -----------------------------------------------------------------------
    // Message length validation
    // -----------------------------------------------------------------------

   
    public String checkMessageLength() {
        if (messageText == null) return "Message ready to send.";
        int len = messageText.length();
        if (len <= 250) {
            return "Message ready to send.";
        }
        int excess = len - 250;
        return "Message exceeds 250 characters by " + excess
                + " [enter number here]; please reduce the size.";
    }

    // -----------------------------------------------------------------------
    // Send / Store / Disregard
    // -----------------------------------------------------------------------

   
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(messageText);
                sentRecipients.add(recipient);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                entryTypes.add("sent");
                totalMessagesSent++;
                storeMessageToJson(recipient, messageText, messageHash, messageID, "sent");
                return "Message successfully sent.";
            case 2:
                disregardedMessages.add(messageText);
                return "Press 0 to delete the message.";
            case 3:
                storedMessages.add(messageText);
                storedRecipients.add(recipient);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                entryTypes.add("stored");
                storeMessageToJson(recipient, messageText, messageHash, messageID, "stored");
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    // -----------------------------------------------------------------------
    // Print / Count helpers
    // -----------------------------------------------------------------------

   
    public static String printMessages() {
        if (sentMessages.isEmpty()) return "No messages sent yet.";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message ID  : ").append(messageIDs.get(i)).append("\n");
            sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("Recipient   : ").append(sentRecipients.get(i)).append("\n");
            sb.append("Message     : ").append(sentMessages.get(i)).append("\n");
            sb.append("------------------------------\n");
        }
        return sb.toString();
    }

   
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    private void storeMessageToJson(String rec, String text,
                                    String hash, String id, String flag) {
       
        StringBuilder existing = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(JSON_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                existing.append(line).append("\n");
            }
        } catch (IOException e) {
         
            existing.append("[]");
        }

        String current = existing.toString().trim();
      
        // Build new entry
        
        String entry = "  {\n"
                + "    \"messageID\": \""   + escapeJson(id)   + "\",\n"
                + "    \"recipient\": \""   + escapeJson(rec)  + "\",\n"
                + "    \"message\": \""     + escapeJson(text) + "\",\n"
                + "    \"messageHash\": \"" + escapeJson(hash) + "\",\n"
                + "    \"flag\": \""        + escapeJson(flag) + "\"\n"
                + "  }";

        String newContent;
        if (current.equals("[]") || current.equals("[ ]")) {
            newContent = "[\n" + entry + "\n]";
        } else {
         
            int closingBracket = current.lastIndexOf(']');
            newContent = current.substring(0, closingBracket).stripTrailing()
                    + ",\n" + entry + "\n]";
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(JSON_FILE))) {
            bw.write(newContent);
        } catch (IOException e) {
            System.out.println("Warning: could not write to JSON file. " + e.getMessage());
        }
    }

   
    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // -----------------------------------------------------------------------
    // Load stored messages 
    // -----------------------------------------------------------------------

 
    public static void loadStoredMessagesFromJson() {
        storedMessages.clear();
        storedRecipients.clear();

        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(JSON_FILE))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
        } catch (IOException e) {
            return; // No file yet — silently skip
        }

        String content = sb.toString();
        // Split into individual objects
        String[] objects = content.split("\\{");
        for (String obj : objects) {
            if (!obj.contains("\"flag\"")) continue;
            String flag      = extractJsonValue(obj, "flag");
            if (!"stored".equalsIgnoreCase(flag)) continue;
            String recipient = extractJsonValue(obj, "recipient");
            String message   = extractJsonValue(obj, "message");
            String hash      = extractJsonValue(obj, "messageHash");
            String id        = extractJsonValue(obj, "messageID");
            if (recipient != null && message != null) {
                storedMessages.add(message);
                storedRecipients.add(recipient);
                if (hash != null && !messageHashes.contains(hash)) messageHashes.add(hash);
                if (id   != null && !messageIDs.contains(id))      messageIDs.add(id);
            }
        }
    }

    
    private static String extractJsonValue(String fragment, String key) {
        String search = "\"" + key + "\": \"";
        int start = fragment.indexOf(search);
        if (start < 0) return null;
        start += search.length();
        int end = fragment.indexOf("\"", start);
        if (end < 0) return null;
        return fragment.substring(start, end)
                .replace("\\\"", "\"")
                .replace("\\n", "\n")
                .replace("\\t", "\t");
    }

    // -----------------------------------------------------------------------
    // Part 3 — Stored Messages Menu features
    // -----------------------------------------------------------------------

   
    public static String displayStoredSenderRecipient(String senderName) {
        if (storedMessages.isEmpty()) return "No stored messages found.";
        StringBuilder sb = new StringBuilder("Stored Messages — Sender / Recipient:\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            sb.append(i + 1).append(". Sender: ").append(senderName)
              .append(" | Recipient: ").append(storedRecipients.get(i)).append("\n");
        }
        return sb.toString().trim();
    }

   
    public static String displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) return "No stored messages found.";
        String longest = storedMessages.get(0);
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) longest = msg;
        }
        return longest;
    }

    
    public static String searchByMessageID(String searchID) {
        int sentPtr = 0, storedPtr = 0;
        for (int i = 0; i < messageIDs.size(); i++) {
            String type = (i < entryTypes.size()) ? entryTypes.get(i) : "sent";
            if (messageIDs.get(i).equals(searchID)) {
                String text, rec;
                if ("sent".equals(type)) {
                    text = (sentPtr < sentMessages.size())
                            ? sentMessages.get(sentPtr) : "Unknown";
                    rec  = (sentPtr < sentRecipients.size())
                            ? sentRecipients.get(sentPtr) : "Unknown";
                } else {
                    text = (storedPtr < storedMessages.size())
                            ? storedMessages.get(storedPtr) : "Unknown";
                    rec  = (storedPtr < storedRecipients.size())
                            ? storedRecipients.get(storedPtr) : "Unknown";
                }
                return "Recipient: " + rec + "\nMessage  : " + text;
            }
            if ("sent".equals(type)) sentPtr++;
            else storedPtr++;
        }
        return "Message ID not found.";
    }

   
    public static String searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentRecipients.get(i).equals(recipientNumber)) {
                sb.append(sentMessages.get(i)).append("\n");
            }
        }
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedRecipients.get(i).equals(recipientNumber)) {
                sb.append(storedMessages.get(i)).append("\n");
            }
        }
        return sb.length() > 0 ? sb.toString().trim() : "No messages found for recipient.";
    }

   
    public static String deleteByMessageHash(String hash) {
        int idx = messageHashes.indexOf(hash);
        if (idx < 0) return "Message hash not found.";

        String type = (idx < entryTypes.size()) ? entryTypes.get(idx) : "sent";
        String deletedText = "";

        // Count how far into the type-specific array this index corresponds to
        int typeCount = 0;
        for (int i = 0; i < idx; i++) {
            if (entryTypes.get(i).equals(type)) typeCount++;
        }

        if ("sent".equals(type)) {
            if (typeCount < sentMessages.size()) {
                deletedText = sentMessages.get(typeCount);
                sentMessages.remove(typeCount);
                sentRecipients.remove(typeCount);
                totalMessagesSent = Math.max(0, totalMessagesSent - 1);
            }
        } else {
            if (typeCount < storedMessages.size()) {
                deletedText = storedMessages.get(typeCount);
                storedMessages.remove(typeCount);
                storedRecipients.remove(typeCount);
            }
        }

        messageHashes.remove(idx);
        messageIDs.remove(idx);
        entryTypes.remove(idx);

        return "Message: \"" + deletedText + "\" successfully deleted.";
    }

   
    public static String displayStoredMessageReport() {
        if (storedMessages.isEmpty()) return "No stored messages to report.";
        StringBuilder sb = new StringBuilder("=== Stored Messages Report ===\n");
        int storedPtr = 0;
        for (int i = 0; i < entryTypes.size() && storedPtr < storedMessages.size(); i++) {
            if ("stored".equals(entryTypes.get(i))) {
                String hash = (i < messageHashes.size()) ? messageHashes.get(i) : "N/A";
                sb.append("Message Hash: ").append(hash).append("\n");
                sb.append("Recipient   : ").append(storedRecipients.get(storedPtr)).append("\n");
                sb.append("Message     : ").append(storedMessages.get(storedPtr)).append("\n");
                sb.append("------------------------------\n");
                storedPtr++;
            }
        }
        return sb.toString().trim();
    }

    // -----------------------------------------------------------------------
    // Test-support helpers
    // -----------------------------------------------------------------------

   
    public static void resetAll() {
        sentMessages.clear();
        sentRecipients.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        storedRecipients.clear();
        messageHashes.clear();
        messageIDs.clear();
        entryTypes.clear();
        totalMessagesSent = 0;
    }

   
    public static void addSentMessage(String text, String recipient,
                                      String hash, String id) {
        sentMessages.add(text);
        sentRecipients.add(recipient);
        messageHashes.add(hash);
        messageIDs.add(id);
        entryTypes.add("sent");
        totalMessagesSent++;
    }

   
    public static void addStoredMessage(String text, String recipient,
                                        String hash, String id) {
        storedMessages.add(text);
        storedRecipients.add(recipient);
        messageHashes.add(hash);
        messageIDs.add(id);
        entryTypes.add("stored");
    }

    public String getMessageID()   { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient()   { return recipient; }
    public String getMessageText() { return messageText; }

    public static List<String> getSentMessages()     { return sentMessages; }
    public static List<String> getSentRecipients()   { return sentRecipients; }
    public static List<String> getStoredMessages()   { return storedMessages; }
    public static List<String> getStoredRecipients() { return storedRecipients; }
    public static List<String> getMessageHashes()    { return messageHashes; }
    public static List<String> getMessageIDs()       { return messageIDs; }
}
