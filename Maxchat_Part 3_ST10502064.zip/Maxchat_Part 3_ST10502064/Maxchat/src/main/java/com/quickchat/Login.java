package com.maxchat;


public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // -----------------------------------------------------------------------
    // Constructors
    // -----------------------------------------------------------------------

    
    public Login(String firstName, String lastName,
                 String username, String password, String cellPhoneNumber) {
        this.firstName       = firstName;
        this.lastName        = lastName;
        this.username        = username;
        this.password        = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // -----------------------------------------------------------------------
    // Validation methods
    // -----------------------------------------------------------------------

   
    public boolean checkUserName() {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

   
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper   = false;
        boolean hasDigit   = false;
        boolean hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c))                  hasUpper   = true;
            else if (Character.isDigit(c))                 hasDigit   = true;
            else if (!Character.isLetterOrDigit(c))        hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

   
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        // Pattern: starts with +, 1-3 digit country code, then up to 10 local digits
        return cellPhoneNumber.matches("^\\+[0-9]{1,3}[0-9]{1,10}$");
    }

    // -----------------------------------------------------------------------
    // Registration / Login
    // -----------------------------------------------------------------------

   
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your "
                    + "username contains an underscore and is no more than five "
                    + "characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the "
                    + "password contains at least eight characters, a capital "
                    + "letter, a number, and a special character.";
        }
        return "Username successfully captured.\nPassword successfully captured.";
    }

    
    
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

   
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    // -----------------------------------------------------------------------
    // Getters (needed by tests and MaxChat)
    // -----------------------------------------------------------------------

    public String getUsername()        { return username; }
    public String getFirstName()       { return firstName; }
    public String getLastName()        { return lastName; }
    public String getCellPhoneNumber() { return cellPhoneNumber; }
}
