package com.maxchat;

import java.util.Scanner;

/**
 * MaxChat — main application entry point.
 *
 * Covers all three parts of the PROG5121 POE:
 *  Part 1: Registration and Login
 *  Part 2: Send Messages (with ID, hash, send/store/disregard)
 *  Part 3: Stored Messages menu (search, delete, report, longest message)
 */
public class MaxChat {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("==========================================");
        System.out.println("        Welcome to MaxChat");
        System.out.println("==========================================\n");

        // ----------------------------------------------------------------
        // PART 1 — Registration
        // ----------------------------------------------------------------
        System.out.println("--- Register your account ---");
        System.out.print("First Name    : ");
        String firstName = scanner.nextLine();

        System.out.print("Last Name     : ");
        String lastName = scanner.nextLine();

        System.out.print("Username      : ");
        String username = scanner.nextLine();

        System.out.print("Password      : ");
        String password = scanner.nextLine();

        System.out.print("Cell Number   : ");
        String cell = scanner.nextLine();

        Login user = new Login(firstName, lastName, username, password, cell);
        System.out.println("\n" + user.registerUser());

        if (!user.checkUserName() || !user.checkPasswordComplexity()) {
            System.out.println("Registration failed. Please restart and try again.");
            scanner.close();
            return;
        }

        if (user.checkCellPhoneNumber()) {
            System.out.println("Cell phone number successfully added.");
        } else {
            System.out.println("Cell phone number incorrectly formatted or does not "
                    + "contain international code.");
        }

        // ----------------------------------------------------------------
        // PART 1 — Login
        // ----------------------------------------------------------------
        System.out.println("\n--- Login ---");
        System.out.print("Username: ");
        String enteredUser = scanner.nextLine();
        System.out.print("Password: ");
        String enteredPass = scanner.nextLine();

        String loginStatus = user.returnLoginStatus(enteredUser, enteredPass);
        System.out.println(loginStatus);

        if (!user.loginUser(enteredUser, enteredPass)) {
            System.out.println("Login failed. Exiting.");
            scanner.close();
            return;
        }

        // ----------------------------------------------------------------
        // PART 2 & 3 — Message session
        // ----------------------------------------------------------------
        System.out.println("\nHow many messages do you want to send this session?");
        int numMessages;
        try {
            numMessages = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Exiting.");
            scanner.close();
            return;
        }

        // Load any previously stored messages from JSON
        Message.loadStoredMessagesFromJson();

        int messageCounter = 0;

        // ----------------------------------------------------------------
        // Main application loop
        // ----------------------------------------------------------------
        boolean running = true;
        while (running) {
            System.out.println("\n==========================================");
            System.out.println("Welcome to MaxChat.");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            System.out.print("Choose an option: ");

            String choiceStr = scanner.nextLine().trim();
            int menuChoice;
            try {
                menuChoice = Integer.parseInt(choiceStr);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number (1-4).");
                continue;
            }

            switch (menuChoice) {

                // -----------------------------------------------------------
                // OPTION 1 — Send Messages
                // -----------------------------------------------------------
                case 1:
                    if (messageCounter >= numMessages) {
                        System.out.println("You have reached your message limit for this session.");
                        break;
                    }

                    for (int i = messageCounter; i < numMessages; i++) {
                        messageCounter++;
                        System.out.println("\n--- Message " + messageCounter + " ---");

                        // Recipient
                        System.out.print("Recipient cell number: ");
                        String rec = scanner.nextLine();

                        // Create temporary message to validate recipient
                        Message temp = new Message(rec, "placeholder", messageCounter);
                        System.out.println(temp.checkRecipientCell());
                        if (!temp.checkRecipientCell()
                                .equals("Cell phone number successfully captured.")) {
                            System.out.println("Skipping message due to invalid recipient.");
                            messageCounter--;
                            break;
                        }

                        // Message text
                        System.out.print("Enter message (max 250 chars): ");
                        String text = scanner.nextLine();

                        Message msg = new Message(rec, text, messageCounter);
                        System.out.println(msg.checkMessageLength());

                        if (!msg.checkMessageLength().equals("Message ready to send.")) {
                            System.out.println("Message too long. Please try again.");
                            messageCounter--;
                            break;
                        }

                        System.out.println("Message ID  : " + msg.getMessageID());
                        System.out.println("Message Hash: " + msg.getMessageHash());
                        System.out.println("Recipient   : " + msg.getRecipient());
                        System.out.println("Message     : " + msg.getMessageText());

                        System.out.println("\n1) Send Message");
                        System.out.println("2) Disregard Message");
                        System.out.println("3) Store Message to send later");
                        System.out.print("Your choice: ");

                        int sendChoice;
                        try {
                            sendChoice = Integer.parseInt(scanner.nextLine().trim());
                        } catch (NumberFormatException e) {
                            sendChoice = 2; 
                        }
                        System.out.println(msg.sentMessage(sendChoice));
                    }

                    System.out.println("\nTotal messages sent this session: "
                            + Message.returnTotalMessages());
                    break;

                // -----------------------------------------------------------
                // OPTION 2 — Show recently sent messages 
                // -----------------------------------------------------------
                case 2:
                    String log = Message.printMessages();
                    System.out.println(log.isEmpty() ? "No messages sent yet." : log);
                    break;

                // -----------------------------------------------------------
                // OPTION 3 — Stored Messages sub-menu (Part 3)
                // -----------------------------------------------------------
                case 3:
                    storedMessagesMenu(scanner, user.getFirstName() + " " + user.getLastName());
                    break;

                // -----------------------------------------------------------
                // OPTION 4 — Quit
                // -----------------------------------------------------------
                case 4:
                    running = false;
                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
                    System.out.println("Thank you for using MaxChat. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1-4.");
            }
        }

        scanner.close();
    }

    // -----------------------------------------------------------------------
    // Part 3 — Stored Messages sub-menu
    // -----------------------------------------------------------------------

   
    private static void storedMessagesMenu(Scanner scanner, String senderName) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message by Message ID");
            System.out.println("d) Search all messages for a particular recipient");
            System.out.println("e) Delete a message using its hash");
            System.out.println("f) Display full stored messages report");
            System.out.println("g) Back to main menu");
            System.out.print("Choose an option: ");

            String opt = scanner.nextLine().trim().toLowerCase();
            System.out.println();

            switch (opt) {
                case "a":
                    System.out.println(Message.displayStoredSenderRecipient(senderName));
                    break;
                case "b":
                    System.out.println("Longest message: "
                            + Message.displayLongestStoredMessage());
                    break;
                case "c":
                    System.out.print("Enter Message ID to search: ");
                    String searchID = scanner.nextLine().trim();
                    System.out.println(Message.searchByMessageID(searchID));
                    break;
                case "d":
                    System.out.print("Enter recipient number: ");
                    String recNum = scanner.nextLine().trim();
                    System.out.println(Message.searchByRecipient(recNum));
                    break;
                case "e":
                    System.out.print("Enter message hash to delete: ");
                    String hash = scanner.nextLine().trim();
                    System.out.println(Message.deleteByMessageHash(hash));
                    break;
                case "f":
                    System.out.println(Message.displayStoredMessageReport());
                    break;
                case "g":
                    inSubMenu = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose a-g.");
            }
        }
    }
}
