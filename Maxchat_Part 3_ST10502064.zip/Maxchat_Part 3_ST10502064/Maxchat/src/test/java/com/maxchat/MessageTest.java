package com.maxchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


class MessageTest {

    // -----------------------------------------------------------------------
    // Part 2 test messages 
    // -----------------------------------------------------------------------
    private Message msg1; 
    private Message msg2; 

    // -----------------------------------------------------------------------
    // Part 3 test messages 
    // -----------------------------------------------------------------------

    @BeforeEach
    void setUp() {
        Message.resetAll();

        // Part 2 messages — use fixed IDs so hash assertions are deterministic
        msg1 = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?", 1, "0034567890");
        msg2 = new Message("08575975889",
                "Hi Keegan, did you receive the payment?", 2, "0078901234");
    }

    // -----------------------------------------------------------------------
    // Part 2 — checkMessageLength
    // -----------------------------------------------------------------------

    @Test
    void testMessageLengthUnder250_returnsReady() {
        assertEquals("Message ready to send.", msg1.checkMessageLength(),
                "Short message should be ready to send.");
    }

    @Test
    void testMessageLengthOver250_returnsError() {
        String longText = "a".repeat(260);
        Message longMsg = new Message("+27711111111", longText, 3, "1234567890");
        String result = longMsg.checkMessageLength();
        assertTrue(result.startsWith("Message exceeds 250 characters by 10"),
                "Should report 10-character excess.");
    }

    // -----------------------------------------------------------------------
    // Part 2 — checkRecipientCell
    // -----------------------------------------------------------------------

    @Test
    void testRecipientCorrectlyFormatted_returnsSuccess() {
        assertEquals("Cell phone number successfully captured.",
                msg1.checkRecipientCell(),
                "+27718693002 is a valid SA number.");
    }

    @Test
    void testRecipientIncorrectlyFormatted_returnsError() {
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain "
                        + "international code. Please correct the number and try again.",
                msg2.checkRecipientCell(),
                "08575975889 has no international code.");
    }

    // -----------------------------------------------------------------------
    // Part 2 — createMessageHash 
    // -----------------------------------------------------------------------

    @Test
    void testMessageHashIsCorrect() {
        assertEquals("00:1:HITONIGHT", msg1.getMessageHash(),
                "Hash should be 00:1:HITONIGHT for message 1 with ID starting '00'.");
    }

    // -----------------------------------------------------------------------
    // Part 2 — sentMessage choices
    // -----------------------------------------------------------------------

    @Test
    void testSentMessage_sendChoice_returnsSuccessfullySent() {
        assertEquals("Message successfully sent.", msg1.sentMessage(1));
    }

    @Test
    void testSentMessage_disregardChoice_returnsPressZero() {
        assertEquals("Press 0 to delete the message.", msg1.sentMessage(2));
    }

    @Test
    void testSentMessage_storeChoice_returnsSuccessfullyStored() {
        assertEquals("Message successfully stored.", msg1.sentMessage(3));
    }

    // -----------------------------------------------------------------------
    // Part 2 — Message ID
    // -----------------------------------------------------------------------

    @Test
    void testMessageIDGenerated_displaysID() {
        String id = msg1.getMessageID();
        assertNotNull(id, "Message ID should not be null.");
        assertTrue(id.length() <= 10, "Message ID should be at most 10 characters.");
        System.out.println("Message ID generated: " + id);
    }
    // -----------------------------------------------------------------------
    // Part 3 — Populate arrays
    // -----------------------------------------------------------------------


    @Test
    void testSentMessagesArrayCorrectlyPopulated() {
        
        assertTrue(Message.getSentMessages().contains("Did you get the cake?"),
                "Sent array should contain message 1.");
        assertTrue(Message.getSentMessages().contains("It is dinner time !"),
                "Sent array should contain message 4.");
    }

    // -----------------------------------------------------------------------
    // Part 3 — displayLongestStoredMessage
    // -----------------------------------------------------------------------

    @Test
    void testDisplayLongestStoredMessage() {
        assertEquals(
                "Where are you? You are late! I have asked you to be on time.",
                Message.displayLongestStoredMessage()
        );
    }

    // -----------------------------------------------------------------------
    // Part 3 — searchByMessageID
    // -----------------------------------------------------------------------

    @Test
    void testSearchByMessageID_found() {
        String result = Message.searchByMessageID("CC12345678");
        assertTrue(result.contains("It is dinner time !"),
                "Search by ID CC12345678 should return message 4 text.");
    }

    // -----------------------------------------------------------------------
    // Part 3 — searchByRecipient
    // -----------------------------------------------------------------------

    @Test
    void testSearchByRecipient_returnsAllMatchingMessages() {
        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."),
                "Should find message 2 for +27838884567.");
        assertTrue(result.contains("Ok, I am leaving without you."),
                "Should find message 5 for +27838884567.");
    }

    // -----------------------------------------------------------------------
    // Part 3 — deleteByMessageHash
    // -----------------------------------------------------------------------

    @Test
    void testDeleteByMessageHash_successfulDeletion() {
        String result = Message.deleteByMessageHash("BB:2:WHERETIME");
        assertTrue(result.contains("successfully deleted"),
                "Deletion confirmation should say 'successfully deleted'.");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."),
                "Deletion message should include the deleted message text.");
    }

    @Test
    void testDeleteByMessageHash_notFound() {
        assertEquals("Message hash not found.",
                Message.deleteByMessageHash("NOTEXIST"),
                "Should return not-found string for unknown hash.");
    }

    // -----------------------------------------------------------------------
    // Part 3 — displayStoredMessageReport
    // -----------------------------------------------------------------------

    @Test
    void testDisplayStoredMessageReport_containsExpectedFields() {
        String report = Message.displayStoredMessageReport();
        assertTrue(report.contains("Message Hash"), "Report should contain hash label.");
        assertTrue(report.contains("Recipient"),    "Report should contain recipient label.");
        assertTrue(report.contains("Message"),      "Report should contain message label.");
        assertTrue(report.contains("+27838884567"), "Report should contain stored recipient.");
    }

    // -----------------------------------------------------------------------
    // Part 3 — returnTotalMessages
    // -----------------------------------------------------------------------

    @Test
    void testReturnTotalMessages_matchesSentCount() {
        assertEquals(2, Message.returnTotalMessages(),
                "Total sent should be 2 (messages 1 and 4).");
    }
}
