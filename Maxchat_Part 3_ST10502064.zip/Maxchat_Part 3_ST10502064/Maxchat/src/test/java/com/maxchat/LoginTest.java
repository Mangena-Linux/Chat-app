package com.maxchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Login class (Part 1).
 */
class LoginTest {

    private Login validLogin;
    private Login invalidLogin;

    @BeforeEach
    void setUp() {
        
        validLogin = new Login("John", "Doe",
                "kyl_1", "Ch&&sec@ke99!", "+27838968976");

       
        invalidLogin = new Login("Jane", "Smith",
                "kyle!!!!!!",  "password", "08966553");
    }

    // -----------------------------------------------------------------------
    // checkUserName
    // -----------------------------------------------------------------------

    @Test
    void testUsernameCorrectlyFormatted_returnsTrue() {
        assertTrue(validLogin.checkUserName(),
                "Username 'kyl_1' should be valid (has _ and <=5 chars).");
    }

    @Test
    void testUsernameIncorrectlyFormatted_returnsFalse() {
        assertFalse(invalidLogin.checkUserName(),
                "Username 'kyle!!!!!!!' should be invalid (no _ and >5 chars).");
    }

    // -----------------------------------------------------------------------
    // checkPasswordComplexity
    // -----------------------------------------------------------------------

    @Test
    void testPasswordMeetsComplexity_returnsTrue() {
        assertTrue(validLogin.checkPasswordComplexity(),
                "'Ch&&sec@ke99!' should meet all complexity rules.");
    }

    @Test
    void testPasswordDoesNotMeetComplexity_returnsFalse() {
        assertFalse(invalidLogin.checkPasswordComplexity(),
                "'password' should fail — no uppercase, digit, or special char.");
    }

    // -----------------------------------------------------------------------
    // checkCellPhoneNumber
    // -----------------------------------------------------------------------

    @Test
    void testCellPhoneCorrectlyFormatted_returnsTrue() {
        assertTrue(validLogin.checkCellPhoneNumber(),
                "'+27838968976' should be valid (starts with +27).");
    }

    @Test
    void testCellPhoneIncorrectlyFormatted_returnsFalse() {
        assertFalse(invalidLogin.checkCellPhoneNumber(),
                "'08966553' should be invalid (no international code).");
    }

    // -----------------------------------------------------------------------
    // registerUser — assertEquals (from POE test table)
    // -----------------------------------------------------------------------

    @Test
    void testRegisterUser_validCredentials_returnsSuccessMessage() {
        assertEquals(
                "Username successfully captured.\nPassword successfully captured.",
                validLogin.registerUser()
        );
    }

    @Test
    void testRegisterUser_invalidUsername_returnsErrorMessage() {
        assertEquals(
                "Username is not correctly formatted; please ensure that your "
                        + "username contains an underscore and is no more than five "
                        + "characters in length.",
                invalidLogin.registerUser()
        );
    }

    // -----------------------------------------------------------------------
    // loginUser — assertTrue / assertFalse
    // -----------------------------------------------------------------------

    @Test
    void testLoginSuccessful_returnsTrue() {
        assertTrue(validLogin.loginUser("kyl_1", "Ch&&sec@ke99!"),
                "Login with correct credentials should return true.");
    }

    @Test
    void testLoginFailed_returnsFalse() {
        assertFalse(validLogin.loginUser("wrong", "wrong"),
                "Login with wrong credentials should return false.");
    }

    // -----------------------------------------------------------------------
    // returnLoginStatus — assertEquals
    // -----------------------------------------------------------------------

    @Test
    void testReturnLoginStatus_success() {
        assertEquals(
                "Welcome John, Doe it is great to see you again.",
                validLogin.returnLoginStatus("kyl_1", "Ch&&sec@ke99!")
        );
    }

    @Test
    void testReturnLoginStatus_failure() {
        assertEquals(
                "Username or password incorrect, please try again.",
                validLogin.returnLoginStatus("kyl_1", "wrongPass")
        );
    }
}
